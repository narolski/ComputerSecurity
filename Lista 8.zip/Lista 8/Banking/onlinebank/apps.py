from django.apps import AppConfig


class OnlinebankConfig(AppConfig):
    name = 'onlinebank'

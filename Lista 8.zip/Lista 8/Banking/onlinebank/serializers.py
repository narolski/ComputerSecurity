# serializers.py
from rest_framework import serializers
from .models import TransferRequest, Transfer

class TransferRequestSerializer(serializers.ModelSerializer):
    from_account = serializers.HiddenField(
        default=serializers.CurrentUserDefault()
    )

    class Meta:
        model = TransferRequest
        fields = ("from_account", "to_account", "title", "amount")

class TransferSerializer(serializers.ModelSerializer):
    from_account = serializers.HiddenField(
        default=serializers.CurrentUserDefault()
    )

    class Meta:
        model = Transfer
        fields = ("from_account", "to_account", "title", "amount", "date")